import React from 'react'

const PaymentSuccessful = () => {
  return (
    <div>
      abebe
    </div>
  )
}

export default PaymentSuccessful
